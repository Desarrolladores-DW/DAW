<?php

    $conexion = mysqli_connect("Localhost", "root", "", "login_codelearn");
    
    /*   
    if($conexion){
        echo 'Conectado Exitosamente a la BD';
    }else{
        echo 'No se a podido conectar a la BD';
    }
    */

?>